package com.example.homework1_onclick;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;




public class MainActivity extends AppCompatActivity {

    private long onCreateTime, onStartTime, onResumeTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        onCreateTime = System.currentTimeMillis();
        Log.d("MainActivity", "onCreate пришёл. Время: " + onCreateTime);

        Button myButton = findViewById(R.id.myButton);
        myButton.setOnClickListener(v -> {
            long currentTime = System.currentTimeMillis();
            Log.d("MainActivity", "Кнопка клацнута!! Время: " + currentTime);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        onStartTime = System.currentTimeMillis();
        Log.d("MainActivity", "onStart заспавнен. Разница с onCreate: " + (onStartTime - onCreateTime) + " мс");
    }

    @Override
    protected void onResume() {
        super.onResume();
        onResumeTime = System.currentTimeMillis();
        Log.d("MainActivity", "onResume покликан. Разница с onStart: " + (onResumeTime - onStartTime) + " мс");
    }

    @Override
    protected void onPause() {
        super.onPause();
        long onPauseTime = System.currentTimeMillis();
        Log.d("MainActivity", "onPause позван. Время: " + onPauseTime);
    }

    @Override
    protected void onStop() {
        super.onStop();
        long onStopTime = System.currentTimeMillis();
        Log.d("MainActivity", "onStop призван. Время: " + onStopTime);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        long onDestroyTime = System.currentTimeMillis();
        Log.d("MainActivity", "onDestroy вызван короче. Время: " + onDestroyTime);
    }

}
